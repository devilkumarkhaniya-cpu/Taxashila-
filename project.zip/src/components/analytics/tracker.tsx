'use client';

import { useEffect, useRef } from 'react';
import { usePathname } from 'next/navigation';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { useFirestore } from '@/firebase';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

export function AnalyticsTracker() {
  const pathname = usePathname();
  const db = useFirestore();
  const startTime = useRef<number>(Date.now());

  useEffect(() => {
    if (!db) return;

    // Reset timer on path change
    startTime.current = Date.now();

    const dataToSave = {
      path: pathname,
      timestamp: serverTimestamp(),
      device: typeof window !== 'undefined' ? window.navigator.userAgent : 'unknown'
    };

    addDoc(collection(db, 'analytics'), dataToSave)
      .catch(async (err) => {
        // Analytics errors are emitted but not blocking
        const permissionError = new FirestorePermissionError({
          path: 'analytics',
          operation: 'create',
          requestResourceData: dataToSave,
        });
        errorEmitter.emit('permission-error', permissionError);
      });

  }, [pathname, db]);

  return null;
}
