import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, Clock, Award, Target } from "lucide-react"

export function StatsGrid() {
  const stats = [
    {
      title: "Tests Completed",
      value: "42",
      description: "+3 from last week",
      icon: Award,
      color: "text-blue-600",
      bg: "bg-blue-100",
    },
    {
      title: "Avg. Accuracy",
      value: "84%",
      description: "Top 5% in your category",
      icon: Target,
      color: "text-primary",
      bg: "bg-primary/20",
    },
    {
      title: "Study Time",
      value: "12.5h",
      description: "Daily avg 1.8h",
      icon: Clock,
      color: "text-green-600",
      bg: "bg-green-100",
    },
    {
      title: "Current Rank",
      value: "#254",
      description: "Out of 12,400 students",
      icon: TrendingUp,
      color: "text-purple-600",
      bg: "bg-purple-100",
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card key={stat.title} className="border-none shadow-sm overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
            <div className={`${stat.bg} p-2 rounded-lg`}>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-black font-headline">{stat.value}</div>
            <p className="text-xs text-muted-foreground mt-1">{stat.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
