
"use client"

import React, { useState, useEffect, useMemo } from 'react'
import Link from 'next/link'
import { Menu, X, BarChart2, LogOut, SearchIcon, Vault, Home, Briefcase, Calendar, Bell, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import { useUser, useAuth, useCollection, useFirestore } from '@/firebase'
import { signOut, GoogleAuthProvider, signInWithPopup } from 'firebase/auth'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { collection, query, limit } from 'firebase/firestore'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet'

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [isSearchActive, setIsSearchActive] = useState(false)
  const { user } = useUser()
  const auth = useAuth()
  const db = useFirestore()

  // Simplified Global Search Logic
  const materialsRef = useMemo(() => db ? query(collection(db, 'studyMaterials'), limit(5)) : null, [db])
  const testsRef = useMemo(() => db ? query(collection(db, 'mockTests'), limit(5)) : null, [db])
  
  const { data: materials } = useCollection(materialsRef)
  const { data: tests } = useCollection(testsRef)

  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return null
    const query = searchQuery.toLowerCase()
    const mats = materials?.filter(m => m.title.toLowerCase().includes(query)) || []
    const tsts = tests?.filter(t => t.title.toLowerCase().includes(query)) || []
    return { materials: mats, tests: tsts }
  }, [searchQuery, materials, tests])

  const navLinks = [
    { name: 'Home', href: '/', icon: Home },
    { name: 'Vault', href: '/pdfs', icon: Vault },
    { name: 'Tests', href: '/mock-tests', icon: BarChart2 },
    { name: 'Jobs', href: '/exam-news', icon: Briefcase },
    { name: 'Calendar', href: '/calendar', icon: Calendar },
  ]

  const handleLogout = async () => {
    if (auth) await signOut(auth);
  };

  const handleLogin = async () => {
    if (!auth) return;
    const provider = new GoogleAuthProvider();
    await signInWithPopup(auth, provider);
  };

  return (
    <>
      <nav className="sticky top-0 z-50 w-full glass-morphism border-b h-16 flex items-center">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between gap-4">
            <Link href="/" className="shrink-0 group">
              <span className="text-xl font-black tracking-tighter text-foreground uppercase font-headline">
                Taksha<span className="text-primary italic">shila</span>
              </span>
            </Link>

            {/* Global Search Bar */}
            <div className="hidden lg:flex relative flex-grow max-w-sm">
              <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search resources..." 
                className="pl-9 h-10 rounded-xl bg-secondary/50 border-none font-bold text-xs"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchActive(true)}
              />
              {isSearchActive && searchResults && (searchQuery.length > 0) && (
                <div className="absolute top-12 left-0 w-full bg-background border rounded-2xl shadow-2xl p-4 space-y-4">
                  <div>
                    <p className="text-[10px] font-black uppercase text-muted-foreground mb-2">Materials</p>
                    {searchResults.materials.length > 0 ? searchResults.materials.map(m => (
                      <Link key={m.id} href="/pdfs" className="block p-2 hover:bg-secondary rounded-lg text-sm font-bold" onClick={() => setIsSearchActive(false)}>
                        {m.title}
                      </Link>
                    )) : <p className="text-xs text-muted-foreground italic">No materials found</p>}
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase text-muted-foreground mb-2">Mock Tests</p>
                    {searchResults.tests.length > 0 ? searchResults.tests.map(t => (
                      <Link key={t.id} href={`/mock-tests/take/${t.id}`} className="block p-2 hover:bg-secondary rounded-lg text-sm font-bold" onClick={() => setIsSearchActive(false)}>
                        {t.title}
                      </Link>
                    )) : <p className="text-xs text-muted-foreground italic">No tests found</p>}
                  </div>
                </div>
              )}
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-6">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  href={link.href}
                  className="text-[10px] font-black transition-all hover:text-primary uppercase tracking-widest"
                >
                  {link.name}
                </Link>
              ))}
              
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative">
                    <Bell className="h-5 w-5" />
                    <span className="absolute top-2 right-2 h-2 w-2 bg-red-600 rounded-full border-2 border-background" />
                  </Button>
                </SheetTrigger>
                <SheetContent>
                  <SheetHeader>
                    <SheetTitle className="font-headline font-black uppercase tracking-tighter">Notifications</SheetTitle>
                  </SheetHeader>
                  <div className="mt-8 space-y-4">
                    <div className="p-4 bg-primary/10 rounded-2xl border border-primary/20">
                      <p className="text-xs font-black uppercase mb-1">New Job Alert</p>
                      <p className="text-sm font-bold">SSC CGL 2026 Recruitment is now live. Check details now!</p>
                    </div>
                    <div className="p-4 bg-secondary/30 rounded-2xl border">
                      <p className="text-xs font-black uppercase mb-1">Mock Test Result</p>
                      <p className="text-sm font-bold">Your Accuracy for 'Blood Relations' test was 85%. View analysis.</p>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>

              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-10 w-10 rounded-full p-0 border-2 border-primary/20">
                      <Avatar className="h-full w-full">
                        <AvatarImage src={user.photoURL || ""} alt={user.displayName || ""} />
                        <AvatarFallback className="bg-primary/10 font-black">{user.displayName?.charAt(0) || "U"}</AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56 rounded-2xl p-2 shadow-2xl border-none" align="end">
                    <DropdownMenuLabel className="font-normal mb-1">
                      <div className="flex flex-col space-y-0.5">
                        <p className="text-xs font-black">{user.displayName}</p>
                        <p className="text-[10px] text-muted-foreground truncate">{user.email}</p>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild className="rounded-xl cursor-pointer font-black text-[10px] uppercase h-10">
                      <Link href="/dashboard" className="flex items-center gap-2">
                        <BarChart2 className="h-4 w-4 text-primary" /> My Ranker Dashboard
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={handleLogout} className="rounded-xl cursor-pointer text-destructive font-black text-[10px] uppercase h-10">
                      <div className="flex items-center gap-2">
                        <LogOut className="h-4 w-4" /> Sign Out
                      </div>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Button onClick={handleLogin} className="bg-foreground text-background font-black text-[10px] px-6 h-10 rounded-xl shadow-lg uppercase tracking-widest">
                  LOGIN
                </Button>
              )}
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button onClick={() => setIsOpen(!isOpen)} className={cn("p-2 rounded-xl bg-secondary text-foreground")}>
                {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className={cn(
          "fixed top-16 left-0 w-full h-fit bg-background z-50 md:hidden border-b shadow-2xl transition-all duration-300", 
          isOpen ? "translate-y-0 opacity-100" : "-translate-y-full opacity-0 pointer-events-none"
        )}>
          <div className="px-4 py-8 space-y-3">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                className="flex items-center gap-3 px-6 py-4 rounded-xl text-lg font-black bg-secondary/30 uppercase tracking-tighter"
                onClick={() => setIsOpen(false)}
              >
                <link.icon className="h-5 w-5 text-primary" />
                {link.name}
              </Link>
            ))}
            <div className="pt-4">
              {!user && <Button onClick={handleLogin} className="w-full h-14 bg-primary text-primary-foreground font-black rounded-xl uppercase text-sm">LOGIN WITH GOOGLE</Button>}
            </div>
          </div>
        </div>
      </nav>
      {isOpen && <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 md:hidden" onClick={() => setIsOpen(false)} />}
    </>
  )
}
