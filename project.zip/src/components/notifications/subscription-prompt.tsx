'use client';

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription 
} from '@/components/ui/dialog';
import { useFirestore } from '@/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { Bell, Sparkles, Loader2, Send, X } from 'lucide-react';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

export function SubscriptionPrompt() {
  const [isOpen, setIsOpen] = useState(false);
  const [showBubble, setShowBubble] = useState(false);
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [hasSubscribed, setHasSubscribed] = useState(false);
  
  const db = useFirestore();
  const { toast } = useToast();

  useEffect(() => {
    const subscribed = localStorage.getItem('takshashila_subscribed');
    if (subscribed) {
      setHasSubscribed(true);
      return;
    }

    // Show the notification bubble after 2 seconds
    const timer = setTimeout(() => {
      setShowBubble(true);
      // Auto-hide the bubble after 5 seconds to avoid covering content
      const hideTimer = setTimeout(() => setShowBubble(false), 5000);
      return () => clearTimeout(hideTimer);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!db || !email) return;

    setLoading(true);
    const subscriberData = {
      email,
      subscribedAt: serverTimestamp(),
      source: 'notification_bell'
    };

    try {
      await addDoc(collection(db, 'subscribers'), subscriberData);
      toast({
        title: "તમે જોડાઈ ગયા છો! 🎉",
        description: "હવે તમને પરીક્ષાની દરેક નવી અપડેટ મળતી રહેશે.",
      });
      localStorage.setItem('takshashila_subscribed', 'true');
      setHasSubscribed(true);
      setIsOpen(false);
      setEmail('');
    } catch (err: any) {
      const permissionError = new FirestorePermissionError({
        path: 'subscribers',
        operation: 'create',
        requestResourceData: subscriberData,
      });
      errorEmitter.emit('permission-error', permissionError);
    } finally {
      setLoading(false);
    }
  };

  if (hasSubscribed) return null;

  return (
    <>
      <div className="fixed bottom-6 right-6 z-[100] flex flex-col items-end gap-4">
        {showBubble && (
          <div className="bg-foreground text-background p-4 rounded-2xl shadow-2xl border-2 border-primary animate-in fade-in slide-in-from-bottom-4 duration-500 relative max-w-[220px] premium-shadow">
            <button 
              onClick={() => setShowBubble(false)}
              className="absolute -top-2 -right-2 bg-primary text-primary-foreground rounded-full p-1 border-2 border-foreground"
            >
              <X className="h-3 w-3" />
            </button>
            <p className="text-[10px] font-black uppercase tracking-widest leading-tight">
              પરીક્ષાની નવી અપડેટ મેળવવા માટે અહીં ક્લિક કરો! 👇
            </p>
          </div>
        )}
        
        <button
          onClick={() => setIsOpen(true)}
          className="h-16 w-16 bg-primary text-primary-foreground rounded-full shadow-2xl flex items-center justify-center hover:scale-110 active:scale-95 transition-all group relative border-4 border-background"
        >
          <Bell className="h-8 w-8 animate-ring" />
          <span className="absolute -top-1 -right-1 h-5 w-5 bg-red-600 rounded-full border-2 border-background animate-pulse" />
        </button>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-md rounded-[3rem] border-4 border-foreground overflow-hidden p-0">
          <div className="bg-foreground text-background p-10 text-center relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-10">
              <Bell className="h-32 w-32" />
            </div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/20 text-primary border border-primary/30 mb-6">
              <Sparkles className="h-4 w-4" />
              <span className="text-[10px] font-black uppercase tracking-widest">News Alert</span>
            </div>
            <DialogTitle className="text-3xl font-black font-headline uppercase tracking-tighter leading-tight mb-2">
              લેટેસ્ટ ન્યૂઝ <br/><span className="text-primary">અપડેટ મેળવો!</span>
            </DialogTitle>
          </div>
          
          <div className="p-10 space-y-6 bg-background">
            <form onSubmit={handleSubscribe} className="space-y-4">
              <Input 
                type="email" 
                placeholder="તમારો ઇમેઇલ" 
                className="h-14 rounded-2xl border-2 font-bold px-6"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <Button 
                type="submit" 
                disabled={loading}
                className="w-full h-16 bg-primary text-primary-foreground font-black text-xl rounded-2xl shadow-xl shadow-primary/20 gap-3"
              >
                {loading ? <Loader2 className="animate-spin" /> : <><Send className="h-5 w-5" /> સબ્સ્ક્રાઇબ કરો</>}
              </Button>
            </form>
          </div>
        </DialogContent>
      </Dialog>

      <style jsx global>{`
        @keyframes ring {
          0% { transform: rotate(0); }
          5% { transform: rotate(15deg); }
          10% { transform: rotate(-15deg); }
          15% { transform: rotate(10deg); }
          20% { transform: rotate(-10deg); }
          25% { transform: rotate(5deg); }
          30% { transform: rotate(-5deg); }
          35% { transform: rotate(0); }
          100% { transform: rotate(0); }
        }
        .animate-ring {
          animation: ring 2s ease infinite;
          transform-origin: top;
        }
      `}</style>
    </>
  );
}
