"use client"

import React, { useState } from 'react'
import { Navbar } from '@/components/navigation/navbar'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Calendar, Newspaper, Share2, Sparkles, Loader2, X } from 'lucide-react'
import { summarizeCurrentAffairs, type CurrentAffairsSummarizerOutput } from '@/ai/flows/current-affairs-summarizer'
import Image from 'next/image'

const articles = [
  {
    id: 1,
    title: "India's New Economic Policy Highlights for 2024-25",
    content: "The government recently unveiled a comprehensive economic roadmap focusing on digital transformation, infrastructure development, and sustainable energy. Key highlights include a 35% increase in capital expenditure and new tax incentives for MSMEs. The policy aims to position India as a global manufacturing hub while ensuring fiscal prudence. Experts suggest this could lead to a GDP growth rate of 7.5% in the next fiscal year.",
    date: "May 24, 2024",
    category: "Economics",
    img: "https://picsum.photos/seed/econ1/800/400"
  },
  {
    id: 2,
    title: "Global Climate Summit: Key Takeaways for Aspirants",
    content: "The recent COP summit in Dubai concluded with historic agreements on fossil fuel transition. Participating nations pledged to triple renewable energy capacity by 2030. For competitive exams, it's crucial to remember the 'Loss and Damage' fund mechanism and the specific targets set for methane emission reduction. India's Panchamrit commitment was also a major talking point.",
    date: "May 22, 2024",
    category: "Environment",
    img: "https://picsum.photos/seed/env1/800/400"
  }
]

export default function CurrentAffairs() {
  const [summaries, setSummaries] = useState<Record<number, CurrentAffairsSummarizerOutput>>({})
  const [loadingIds, setLoadingIds] = useState<Set<number>>(new Set())

  const handleSummarize = async (articleId: number, content: string) => {
    setLoadingIds(prev => new Set(prev).add(articleId))
    try {
      const summary = await summarizeCurrentAffairs({ articleContent: content })
      setSummaries(prev => ({ ...prev, [articleId]: summary }))
    } catch (error) {
      console.error("AI summarization failed", error)
    } finally {
      setLoadingIds(prev => {
        const next = new Set(prev)
        next.delete(articleId)
        return next
      })
    }
  }

  return (
    <div className="min-h-screen bg-secondary/20 pb-20">
      <Navbar />
      <main className="container mx-auto px-4 py-12 max-w-4xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <h1 className="text-4xl font-black font-headline mb-2">Current Affairs Portal</h1>
            <p className="text-muted-foreground">Daily updates curated for competitive exam success.</p>
          </div>
          <div className="flex gap-2">
            <Button variant="secondary" className="font-bold">Weekly Roundup</Button>
            <Button variant="secondary" className="font-bold">Monthly Magazine</Button>
          </div>
        </div>

        <div className="space-y-12">
          {articles.map((article) => (
            <Card key={article.id} className="border-none shadow-xl overflow-hidden bg-background">
              <div className="relative h-64 md:h-80 w-full">
                <Image 
                  src={article.img} 
                  alt={article.title} 
                  fill 
                  className="object-cover"
                  data-ai-hint="news coverage"
                />
                <div className="absolute top-4 left-4">
                  <Badge className="bg-primary text-primary-foreground font-bold">{article.category}</Badge>
                </div>
              </div>
              <CardHeader className="pt-8 px-8">
                <div className="flex items-center gap-2 text-xs text-muted-foreground font-bold mb-3 uppercase tracking-widest">
                  <Calendar className="h-3 w-3" />
                  {article.date}
                </div>
                <CardTitle className="text-2xl md:text-3xl font-black font-headline leading-tight">
                  {article.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="px-8 pb-8">
                <p className="text-muted-foreground leading-relaxed mb-8">
                  {article.content}
                </p>

                {summaries[article.id] ? (
                  <div className="bg-primary/5 rounded-2xl p-6 border-2 border-primary/20 relative">
                    <button 
                      onClick={() => setSummaries(prev => {
                        const next = {...prev}
                        delete next[article.id]
                        return next
                      })}
                      className="absolute top-4 right-4 text-muted-foreground hover:text-foreground"
                    >
                      <X className="h-4 w-4" />
                    </button>
                    <h4 className="flex items-center gap-2 text-primary font-black uppercase text-xs tracking-[0.2em] mb-4">
                      <Sparkles className="h-4 w-4" /> AI Summary for Aspirants
                    </h4>
                    <p className="text-sm font-medium leading-relaxed mb-4">
                      {summaries[article.id].summary}
                    </p>
                    <div className="space-y-2">
                      <p className="text-xs font-bold text-muted-foreground uppercase">Key Exam Points:</p>
                      <ul className="list-disc list-inside space-y-1">
                        {summaries[article.id].keyPoints.map((point, idx) => (
                          <li key={idx} className="text-sm text-muted-foreground">{point}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-6 bg-secondary/30 rounded-2xl border">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
                        <Sparkles className="h-5 w-5 text-primary" />
                      </div>
                      <p className="text-sm font-bold">Short on time? Get the AI Exam Summary.</p>
                    </div>
                    <Button 
                      onClick={() => handleSummarize(article.id, article.content)}
                      disabled={loadingIds.has(article.id)}
                      className="bg-foreground text-background font-bold px-6"
                    >
                      {loadingIds.has(article.id) ? (
                        <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Summarizing...</>
                      ) : (
                        'Generate Summary'
                      )}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}
