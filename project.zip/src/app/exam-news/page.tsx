
'use client';

import React, { useMemo, useState } from 'react';
import { Navbar } from '@/components/navigation/navbar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCollection, useFirestore } from '@/firebase';
import { collection, query, orderBy } from 'firebase/firestore';
import { Megaphone, ExternalLink, Search, Clock, Loader2, Info } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

const featuredNews = [
  { id: 'feat-1', title: 'GPSC Class 1-2 Recruitment 2024', category: 'GPSC', description: 'ગુજરાત જાહેર સેવા આયોગ દ્વારા વર્ગ-૧ અને વર્ગ-૨ ની નવી ભરતી જાહેર. કુલ ૧૬૦+ જગ્યાઓ.', details: 'લાયકાત: કોઈપણ વિદ્યાશાખામાં સ્નાતક', lastDate: '31-08-2024', applyLink: 'https://gpsc-ojas.gujarat.gov.in', isNew: true, isClosingSoon: false },
  { id: 'feat-2', title: 'Gujarat Police Constable (12,000+ Posts)', category: 'Police', description: 'લોકરક્ષક ભરતી બોર્ડ દ્વારા કોન્સ્ટેબલ અને PSI ની બંપર ભરતી. શારીરિક કસોટી ટૂંક સમયમાં.', details: 'લાયકાત: ૧૨ પાસ / સ્નાતક', lastDate: '15-09-2024', applyLink: 'https://ojas.gujarat.gov.in', isNew: true, isClosingSoon: false },
  { id: 'feat-3', title: 'GSSSB Junior Clerk Exam Dates', category: 'GSSSB', description: 'ગૌણ સેવા પસંદગી મંડળ દ્વારા જૂનિયર ક્લાર્ક અને સિનિયર ક્લાર્ક પરીક્ષાનું નવું શેડ્યૂલ.', details: 'સીધી ભરતી પરીક્ષા ૨૦૨૪', lastDate: 'Immediate', applyLink: 'https://gsssb.gujarat.gov.in', isNew: false, isClosingSoon: true },
  { id: 'feat-4', title: 'SSC CGL 2024 Notification', category: 'SSC', description: 'કેન્દ્રીય કર્મચારી પસંદગી આયોગ દ્વારા ગ્રેજ્યુએટ લેવલની ૧૭,૦૦૦+ જગ્યાઓ.', lastDate: '24-07-2024', applyLink: 'https://ssc.gov.in', isNew: false, isClosingSoon: true },
  { id: 'feat-5', title: 'High Court Bailiff/Driver Result', category: 'Judiciary', description: 'ગુજરાત હાઇકોર્ટ ડ્રાઈવર અને બેલિફ ભરતીનું પરિણામ જાહેર.', details: 'મેરિટ લિસ્ટ ઉપલબ્ધ છે.', lastDate: 'Published', applyLink: 'https://gujarathighcourt.nic.in', isNew: true, isClosingSoon: false }
];

export default function ExamNewsPage() {
  const [search, setSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const db = useFirestore();
  
  const newsQuery = useMemo(() => (db ? query(collection(db, 'examNews'), orderBy('createdAt', 'desc')) : null), [db]);
  const { data: dbNews, loading: newsLoading } = useCollection(newsQuery);

  const categories = ['All', 'GPSC', 'GSSSB', 'Police', 'SSC', 'Railway', 'Judiciary'];

  const allNews = useMemo(() => {
    let list = [...featuredNews];
    if (dbNews) {
      dbNews.forEach(item => {
        if (!list.find(f => f.title === item.title)) {
          list.push({ ...item, id: item.id });
        }
      });
    }
    if (activeFilter !== 'All') list = list.filter(item => item.category === activeFilter);
    if (search) list = list.filter(item => item.title.toLowerCase().includes(search.toLowerCase()) || item.category.toLowerCase().includes(search.toLowerCase()));
    return list;
  }, [dbNews, activeFilter, search]);

  return (
    <div className="min-h-screen bg-secondary/10 pb-20">
      <Navbar />
      <main className="container mx-auto px-4 py-12 max-w-7xl">
        <header className="mb-12">
          <div className="flex items-center gap-2 text-primary font-black text-[10px] tracking-[0.3em] uppercase mb-4">
            <Megaphone className="h-4 w-4" /> Official Notifications
          </div>
          <h1 className="text-5xl font-black font-headline tracking-tighter uppercase mb-4">Exam <span className="text-primary italic">News</span></h1>
          <p className="text-muted-foreground font-bold text-lg max-w-2xl">ગુજરાત અને કેન્દ્ર સરકારની તમામ ભરતીઓની લેટેસ્ટ માહિતી મેળવો.</p>
        </header>

        <div className="flex flex-col md:flex-row gap-4 mb-10">
          <div className="relative flex-grow">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="ભરતી શોધો (દા.ત. Police, GPSC)..." 
              className="h-12 pl-12 rounded-xl bg-background font-bold shadow-sm"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
            {categories.map(cat => (
              <button key={cat} onClick={() => setActiveFilter(cat)} className={cn(
                "h-12 px-6 rounded-xl font-black text-[10px] uppercase tracking-widest whitespace-nowrap border-2 transition-all",
                activeFilter === cat ? "bg-primary text-primary-foreground border-primary" : "bg-background border-transparent"
              )}>{cat}</button>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in duration-500">
          {allNews.map(news => (
            <Card key={news.id} className="border-none shadow-xl rounded-[2.5rem] overflow-hidden bg-background flex flex-col transition-all hover:translate-y-[-4px]">
              <CardHeader className="p-8 pb-0">
                <div className="flex justify-between items-start mb-4">
                  <Badge className="bg-primary/10 text-primary border-none font-black text-[9px] uppercase px-3 py-1">{news.category}</Badge>
                  <div className="flex gap-1">
                    {news.isNew && <Badge className="bg-green-500 text-white border-none font-black text-[9px] uppercase">NEW</Badge>}
                    {news.isClosingSoon && <Badge className="bg-red-500 text-white border-none font-black text-[9px] uppercase">URGENT</Badge>}
                  </div>
                </div>
                <CardTitle className="text-2xl font-black font-headline tracking-tight uppercase leading-tight">{news.title}</CardTitle>
              </CardHeader>
              <CardContent className="p-8 flex-grow space-y-6">
                <p className="text-sm font-bold text-muted-foreground line-clamp-2">{news.description}</p>
                
                {news.details && (
                  <div className="flex items-start gap-2 text-xs font-bold text-primary italic">
                    <Info className="h-4 w-4 shrink-0" />
                    <span>{news.details}</span>
                  </div>
                )}

                <div className="p-4 bg-secondary/40 rounded-2xl border-2 border-dashed border-zinc-200">
                   <div className="flex items-center gap-2 text-[10px] font-black text-muted-foreground uppercase mb-1">
                      <Clock className="h-3 w-3" /> છેલ્લી તારીખ
                   </div>
                   <p className="text-lg font-black text-foreground">{news.lastDate || 'તુરંત'}</p>
                </div>
                <Button asChild className="w-full h-14 bg-foreground text-background font-black rounded-xl shadow-lg hover:scale-[1.02] transition-all">
                  <a href={news.applyLink} target="_blank" rel="noopener noreferrer">અરજી કરો <ExternalLink className="ml-2 h-4 w-4" /></a>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
}
