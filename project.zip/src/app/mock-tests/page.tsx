"use client"

import React from 'react'
import { Navbar } from '@/components/navigation/navbar'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { 
  Search, 
  Award, 
  Zap,
  Play
} from 'lucide-react'
import Link from 'next/link'
import { useCollection, useFirestore } from '@/firebase'
import { collection, query, orderBy } from 'firebase/firestore'
import { cn } from '@/lib/utils'
import { getAllPracticeSets } from '@/lib/static-tests'

export default function MockTests() {
  const [searchQuery, setSearchQuery] = React.useState("")
  const db = useFirestore()
  
  const manualTestsQuery = React.useMemo(() => (db ? query(collection(db, 'mockTests'), orderBy('createdAt', 'desc')) : null), [db]);
  const { data: manualTests } = useCollection(manualTestsQuery);

  const practiceSets = React.useMemo(() => getAllPracticeSets(), []);
  
  const filteredSets = practiceSets.filter(t => 
    t.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    t.subject.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredManual = manualTests?.filter(t => 
    t.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    t.subject.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-secondary/10 pb-20">
      <Navbar />
      <main className="container mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-10 gap-6">
          <div>
            <h1 className="text-4xl font-black font-headline mb-2 uppercase tracking-tighter">Practice Examinations</h1>
            <p className="text-muted-foreground font-medium">Reliable Offline Practice Rounds - Instant Access.</p>
          </div>
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search rounds..." 
              className="pl-10 h-11 border-2 bg-background" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="space-y-16">
          {/* Main Practice Rounds */}
          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="h-10 w-10 bg-primary/20 rounded-xl flex items-center justify-center">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <h2 className="text-2xl font-black uppercase tracking-widest font-headline">Ranker Series (Set 1-50)</h2>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
              {filteredSets.slice(0, 9).map((test) => (
                <TestCard key={test.id} test={{...test, type: "Practice Round", time: "15 mins"}} />
              ))}
            </div>

            {/* Compact List for all 50 rounds */}
            <div className="bg-background rounded-[2.5rem] border-4 border-foreground p-10 shadow-xl">
              <h3 className="text-xl font-black uppercase mb-8 flex items-center gap-2">
                <Award className="h-6 w-6 text-primary" /> Browse All 50 Rounds
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {filteredSets.map((test) => (
                  <Link 
                    key={test.id} 
                    href={`/mock-tests/take/${test.id}`} 
                    className="p-4 bg-secondary/20 border-2 rounded-2xl flex flex-col items-center justify-center hover:border-primary hover:bg-primary/5 transition-all group text-center"
                  >
                    <p className="font-black text-sm group-hover:text-primary transition-colors">{test.title}</p>
                    <p className="text-[8px] font-bold text-muted-foreground uppercase mt-1">{test.subject}</p>
                  </Link>
                ))}
              </div>
            </div>
          </div>

          {/* Official Library Section */}
          {filteredManual && filteredManual.length > 0 && (
            <div>
              <div className="flex items-center gap-3 mb-8">
                <div className="h-10 w-10 bg-primary/20 rounded-xl flex items-center justify-center">
                  <Award className="h-6 w-6 text-primary" />
                </div>
                <h2 className="text-2xl font-black uppercase tracking-widest font-headline">Official Library Tests</h2>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredManual.map((test) => (
                  <TestCard 
                    key={test.id} 
                    test={{
                      id: test.id,
                      title: test.title,
                      subject: test.subject,
                      questions: test.questions?.length || 0,
                      time: `${test.durationMinutes || 15} mins`,
                      difficulty: test.difficulty || 'medium',
                      type: "Official",
                    }} 
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

function TestCard({ test }: { test: any }) {
  return (
    <Card className="relative overflow-hidden group hover:border-primary transition-all duration-300 bg-background border-2 rounded-[2rem] shadow-sm">
      <CardHeader className="p-8">
        <div className="flex items-center gap-3 mb-4">
          <Badge variant="secondary" className="text-[10px] font-black uppercase tracking-widest bg-primary/10 text-primary border-none">
            {test.type}
          </Badge>
          <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
          <span className="text-[10px] text-muted-foreground font-black uppercase tracking-widest">{test.subject}</span>
        </div>
        <CardTitle className="text-2xl font-black group-hover:text-primary transition-colors font-headline leading-tight">
          {test.title}
        </CardTitle>
      </CardHeader>
      <CardContent className="px-8 pb-8">
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-2 text-sm font-bold text-zinc-600">
            <Zap className="h-5 w-5 text-primary" />
            15 MCQ
          </div>
          <div className="flex items-center gap-2 text-sm font-bold text-zinc-600">
            <Timer className="h-5 w-5 text-primary" />
            15 Mins
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-8 pt-6 border-t bg-secondary/30 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Award className="h-5 w-5 text-primary" />
          <span className="text-[10px] font-black uppercase tracking-tighter">Ready to Play</span>
        </div>
        <Button asChild className="bg-primary text-primary-foreground font-black hover:bg-primary/90 shadow-xl shadow-primary/20 rounded-xl px-8">
          <Link href={`/mock-tests/take/${test.id}`}><Play className="mr-2 h-4 w-4" /> Start</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

function Timer({ className }: { className?: string }) {
  return <Zap className={className} />;
}
