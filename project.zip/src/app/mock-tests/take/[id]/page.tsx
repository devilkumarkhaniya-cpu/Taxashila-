
"use client"

import React, { useState, useEffect, useMemo, useCallback } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Navbar } from '@/components/navigation/navbar'
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { Loader2, AlertCircle, Trophy, ArrowRight, ArrowLeft, Timer, Zap, Share2, FastForward } from 'lucide-react'
import { generateMCQs, type MCQGenerationOutput } from '@/ai/flows/ai-mcq-generation'
import { useDoc, useFirestore, useUser } from '@/firebase'
import { doc, addDoc, collection, serverTimestamp } from 'firebase/firestore'
import Link from 'next/link'
import { cn } from '@/lib/utils'
import { getPracticeSetById } from '@/lib/static-tests'

const aiPresetTests = [
  { id: 'ai-mega', title: "Mega Full Mock Test 2024", subject: "Mixed", topic: "All Topics", difficulty: "medium", count: 50, time: 60 },
  { id: 'ai-1', title: "AI Diagnostic: Percentage", subject: "Maths", topic: "Percentage", difficulty: "medium", count: 15, time: 20 },
  { id: 'ai-2', title: "AI Diagnostic: Grammar", subject: "English", topic: "Grammar", difficulty: "easy", count: 15, time: 15 },
  { id: 'ai-3', title: "AI Diagnostic: Blood Relation", subject: "Reasoning", topic: "Blood Relation", difficulty: "medium", count: 13, time: 18 },
]

export default function TakeTest() {
  const params = useParams()
  const router = useRouter()
  const testId = (params?.id as string) || ''
  const { user } = useUser()
  const db = useFirestore()
  
  const isAiTest = useMemo(() => testId.startsWith('ai-'), [testId])
  const isPracticeSet = useMemo(() => testId.startsWith('set-'), [testId])
  
  const manualTestRef = useMemo(() => (db && !isAiTest && !isPracticeSet ? doc(db, 'mockTests', testId) : null), [db, testId, isAiTest, isPracticeSet]);
  const { data: manualTestData, loading: manualLoading } = useDoc(manualTestRef as any);

  const [testState, setTestState] = useState<'START' | 'IN_PROGRESS' | 'COMPLETED'>('START')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [quizData, setQuizData] = useState<MCQGenerationOutput | null>(null)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({})
  const [timeLeft, setTimeLeft] = useState(15 * 60)
  const [testTitle, setTestTitle] = useState("")

  useEffect(() => {
    async function initTest() {
      if (!testId) return;
      setLoading(true);
      try {
        if (isPracticeSet) {
          const set = getPracticeSetById(testId);
          if (set) {
            setTestTitle(set.title);
            setQuizData({ mcqs: set.questions });
            setTimeLeft(15 * 60);
          } else {
            throw new Error("Practice set not found.");
          }
        } else if (isAiTest) {
          const preset = aiPresetTests.find(t => t.id === testId) || aiPresetTests[0];
          setTestTitle(preset.title);
          const data = await generateMCQs({
            subject: preset.subject,
            topic: preset.topic,
            numQuestions: preset.count,
            difficulty: preset.difficulty as any
          });
          if (data && data.mcqs) {
            setQuizData(data);
            setTimeLeft(preset.time * 60);
          }
        } else if (!manualLoading) {
          if (manualTestData) {
            setTestTitle((manualTestData as any).title || "Official Mock Test");
            setQuizData({ mcqs: (manualTestData as any).questions || [] });
            setTimeLeft(((manualTestData as any).durationMinutes || 15) * 60);
          }
        }
        setLoading(false);
      } catch (err: any) {
        console.error(err);
        setError("AI generation unavailable. Please try an Offline Practice Set.");
        setLoading(false);
      }
    }
    initTest();
  }, [testId, isAiTest, isPracticeSet, manualTestData, manualLoading]);

  useEffect(() => {
    if (testState !== 'IN_PROGRESS') return;
    if (timeLeft <= 0) {
      handleCompleteTest();
      return;
    }
    const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    return () => clearInterval(timer);
  }, [timeLeft, testState]);

  const handleCompleteTest = useCallback(() => {
    if (!quizData) return;
    setTestState('COMPLETED');
    if (!db || !user) return;
    let score = 0;
    quizData.mcqs.forEach((q, idx) => {
      if (userAnswers[idx] === q.correctAnswer) score++;
    });
    const total = quizData.mcqs.length;
    const accuracy = total > 0 ? Math.round((score / total) * 100) : 0;
    addDoc(collection(db, 'testResults'), {
      userId: user.uid,
      testId,
      testTitle,
      score,
      total,
      accuracy,
      timeTaken: (quizData.mcqs.length * 60) - timeLeft,
      completedAt: serverTimestamp()
    });
  }, [db, user, quizData, userAnswers, testId, testTitle, timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const nextSetId = useMemo(() => {
    if (!isPracticeSet) return null;
    const currentNum = parseInt(testId.split('-')[1]);
    return currentNum < 50 ? `set-${currentNum + 1}` : null;
  }, [testId, isPracticeSet]);

  if (loading) return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background">
      <div className="text-center">
        <Loader2 className="h-16 w-16 text-primary animate-spin mb-6 mx-auto" />
        <h2 className="text-2xl font-black uppercase tracking-tight mb-2">Takshashila is Preparing Your Paper...</h2>
        <p className="font-bold text-muted-foreground italic">High-Speed Education Portal</p>
      </div>
    </div>
  )

  if (error) return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
      <Card className="max-w-md w-full border-4 border-foreground rounded-[2rem] p-10 text-center">
        <AlertCircle className="h-16 w-16 text-destructive mx-auto mb-6" />
        <h2 className="text-2xl font-black mb-4 uppercase tracking-tighter">Connection Issue</h2>
        <p className="text-muted-foreground font-bold mb-8">{error}</p>
        <Button asChild className="w-full h-14 font-black rounded-xl">
          <Link href="/mock-tests">GO TO PRACTICE SETS</Link>
        </Button>
      </Card>
    </div>
  )

  if (testState === 'START') return (
    <div className="min-h-screen bg-secondary/10">
      <Navbar />
      <main className="container mx-auto px-4 py-12 max-w-3xl">
        <Card className="border-none shadow-2xl rounded-[3rem] overflow-hidden bg-background">
          <div className="bg-foreground text-background p-12 text-center">
            <Trophy className="h-20 w-20 text-primary mx-auto mb-6" />
            <h1 className="text-4xl font-black font-headline tracking-tighter uppercase mb-2">{testTitle}</h1>
            <Badge className="bg-primary/20 text-primary border-none px-6 py-1 font-black text-[10px] uppercase">Official Ranker Series</Badge>
          </div>
          <CardContent className="p-12 space-y-8">
            <div className="grid grid-cols-2 gap-6">
              <div className="p-6 bg-secondary/30 rounded-2xl border flex items-center gap-4">
                <Timer className="h-6 w-6 text-primary" />
                <div><p className="text-[9px] font-black uppercase text-muted-foreground">Time</p><p className="text-xl font-black">{Math.floor(timeLeft / 60)}m</p></div>
              </div>
              <div className="p-6 bg-secondary/30 rounded-2xl border flex items-center gap-4">
                <Zap className="h-6 w-6 text-primary" />
                <div><p className="text-[9px] font-black uppercase text-muted-foreground">MCQs</p><p className="text-xl font-black">{quizData?.mcqs.length || 0}</p></div>
              </div>
            </div>
            <Button 
              onClick={() => setTestState('IN_PROGRESS')} 
              className="w-full h-16 bg-primary text-primary-foreground font-black text-xl rounded-2xl shadow-xl shadow-primary/20 hover:scale-[1.02] transition-transform"
            >
              START TEST NOW
            </Button>
          </CardContent>
        </Card>
      </main>
    </div>
  )

  if (testState === 'COMPLETED') {
    let score = 0;
    quizData?.mcqs.forEach((q, idx) => {
      if (userAnswers[idx] === q.correctAnswer) score++;
    });
    const total = quizData?.mcqs.length || 0;
    const accuracy = total > 0 ? Math.round((score / total) * 100) : 0;
    return (
      <div className="min-h-screen bg-secondary/10 pb-20">
        <Navbar />
        <main className="container mx-auto px-4 py-12 max-w-4xl">
          <Card className="border-none shadow-2xl rounded-[3rem] overflow-hidden bg-background">
            <div className="bg-foreground text-background p-12 text-center">
              <Trophy className="h-20 w-20 text-primary mx-auto mb-6" />
              <h1 className="text-5xl font-black font-headline tracking-tighter uppercase">Result: {score}/{total}</h1>
            </div>
            <CardContent className="p-12">
               <div className="grid grid-cols-2 gap-8 mb-12">
                  <div className="p-10 bg-secondary/30 rounded-[2.5rem] text-center border-2">
                    <p className="text-xs font-black text-muted-foreground uppercase mb-2">Accuracy</p>
                    <p className="text-6xl font-black text-primary">{accuracy}%</p>
                  </div>
                  <div className="p-10 bg-secondary/30 rounded-[2.5rem] text-center border-2">
                    <p className="text-xs font-black text-muted-foreground uppercase mb-2">Time Taken</p>
                    <p className="text-4xl font-black">{formatTime((quizData?.mcqs.length || 0) * 60 - timeLeft)}</p>
                  </div>
               </div>
               <div className="space-y-4">
                  {nextSetId ? (
                    <Button 
                      onClick={() => router.push(`/mock-tests/take/${nextSetId}`)}
                      className="w-full h-16 bg-primary text-primary-foreground font-black rounded-2xl text-lg gap-3 shadow-xl hover:scale-105 transition-transform"
                    >
                      GO TO NEXT ROUND <FastForward className="h-6 w-6" />
                    </Button>
                  ) : (
                    <Button onClick={() => router.push('/mock-tests')} className="w-full h-16 bg-primary text-primary-foreground font-black rounded-2xl text-lg">
                      BACK TO ALL TESTS
                    </Button>
                  )}
                  <div className="flex gap-4">
                    <Button onClick={() => {
                      const text = `🎯 I scored ${score}/${total} (${accuracy}%) on Takshashila Mock Test! Can you beat my rank? 🚀`;
                      window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
                    }} className="flex-grow h-14 bg-[#25D366] text-white font-black rounded-2xl gap-2 hover:opacity-90">
                      <Share2 className="h-5 w-5" /> SHARE RESULT
                    </Button>
                    <Button onClick={() => router.push('/dashboard')} variant="outline" className="flex-grow h-14 border-2 font-black rounded-2xl">
                      STUDENT HUB
                    </Button>
                  </div>
               </div>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  const currentQ = quizData?.mcqs[currentQuestionIndex]
  const progress = ((currentQuestionIndex + 1) / (quizData?.mcqs.length || 1)) * 100
  return (
    <div className="min-h-screen bg-secondary/10 pb-20 select-none">
      <Navbar />
      <main className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
             <div className="h-14 w-14 rounded-2xl bg-primary/20 flex items-center justify-center font-black text-2xl text-primary border-2 border-primary/30">
                {currentQuestionIndex + 1}
             </div>
             <div><h2 className="text-2xl font-black uppercase tracking-tighter truncate max-w-md">{testTitle}</h2></div>
          </div>
          <div className="flex items-center gap-3 bg-foreground text-background px-8 py-3 rounded-2xl font-black text-2xl shadow-xl">
             <Timer className="h-6 w-6 text-primary" /> {formatTime(timeLeft)}
          </div>
        </div>
        <div className="h-4 w-full bg-background rounded-full overflow-hidden mb-8 border-2 shadow-inner">
           <div className="h-full bg-primary transition-all duration-700 ease-out" style={{ width: `${progress}%` }} />
        </div>
        <Card className="border-none shadow-2xl rounded-[3rem] overflow-hidden bg-background">
          <CardHeader className="p-10 md:p-14 bg-primary/5 border-b">
            <CardTitle className="text-2xl md:text-3xl font-black leading-tight text-foreground/90">
              {currentQ?.question}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-10 md:p-14">
            <RadioGroup 
              value={userAnswers[currentQuestionIndex] || ""} 
              onValueChange={(v) => setUserAnswers(prev => ({ ...prev, [currentQuestionIndex]: v }))} 
              className="grid gap-6"
            >
              {currentQ?.options.map((option, idx) => (
                <div 
                  key={idx} 
                  className={cn(
                    "flex items-center space-x-6 p-8 rounded-[2rem] border-2 transition-all cursor-pointer group",
                    userAnswers[currentQuestionIndex] === option ? 'border-primary bg-primary/10 shadow-lg' : 'border-secondary hover:border-primary/40 hover:bg-secondary/20'
                  )} 
                  onClick={() => setUserAnswers(prev => ({ ...prev, [currentQuestionIndex]: option }))}
                >
                  <div className={cn(
                    "h-10 w-10 rounded-full border-2 flex items-center justify-center font-black text-sm transition-colors",
                    userAnswers[currentQuestionIndex] === option ? 'bg-primary border-primary text-background' : 'border-zinc-300 group-hover:border-primary'
                  )}>
                    {String.fromCharCode(65 + idx)}
                  </div>
                  <RadioGroupItem value={option} id={`opt-${idx}`} className="sr-only" />
                  <Label htmlFor={`opt-${idx}`} className="flex-grow cursor-pointer font-bold text-xl leading-snug">{option}</Label>
                </div>
              ))}
            </RadioGroup>
          </CardContent>
          <CardFooter className="p-10 md:p-14 border-t bg-secondary/10 flex justify-between gap-6">
            <Button variant="outline" onClick={() => setCurrentQuestionIndex(prev => prev - 1)} disabled={currentQuestionIndex === 0} className="h-16 px-10 border-4 font-black rounded-2xl text-lg">
              <ArrowLeft className="mr-3 h-6 w-6" /> PREV
            </Button>
            {currentQuestionIndex === (quizData?.mcqs.length || 1) - 1 ? (
              <Button onClick={handleCompleteTest} className="h-16 px-14 bg-green-600 text-white font-black rounded-2xl hover:bg-green-700 shadow-xl shadow-green-100 text-lg">
                SUBMIT TEST
              </Button>
            ) : (
              <Button onClick={() => setCurrentQuestionIndex(prev => prev + 1)} className="h-16 px-12 bg-primary text-primary-foreground font-black rounded-2xl text-lg hover:scale-105 transition-transform">
                NEXT <ArrowRight className="ml-3 h-6 w-6" />
              </Button>
            )}
          </CardFooter>
        </Card>
      </main>
    </div>
  )
}
