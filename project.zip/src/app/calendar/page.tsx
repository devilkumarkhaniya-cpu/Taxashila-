
"use client"

import React, { useMemo } from 'react'
import { Navbar } from '@/components/navigation/navbar'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Calendar as CalendarIcon, Bell, Info } from 'lucide-react'
import { useCollection, useFirestore } from '@/firebase'
import { collection, query, orderBy } from 'firebase/firestore'
import { cn } from '@/lib/utils'

const staticEvents = [
  { id: '1', title: 'GPSC Class 1-2 Prelims', date: '2024-10-13', type: 'EXAM', details: 'વર્ગ-૧ અને ૨ ની પ્રિલિમ પરીક્ષા' },
  { id: '2', title: 'Police Constable Physical Test', date: '2024-11-20', type: 'EXAM', details: 'શારીરિક કસોટી સંભવિત તારીખ' },
  { id: '3', title: 'GSSSB Junior Clerk Result', date: '2024-09-05', type: 'RESULT', details: 'મેરિટ લિસ્ટ gsssb.gujarat.gov.in પર' },
  { id: '4', title: 'SSC CGL Tier 1 Exam', date: '2024-09-09', type: 'EXAM', details: 'Staff Selection Commission Exam' },
  { id: '5', title: 'TAT Secondary Mains Result', date: '2024-08-25', type: 'RESULT', details: 'શિક્ષક અભિરૂચિ કસોટી પરિણામ' },
  { id: '6', title: 'Gujarat High Court Admit Card', date: '2024-07-28', type: 'ADMIT_CARD', details: 'ડ્રાઈવર અને બેલિફ ભરતી એડમિટ કાર્ડ' }
]

export default function ExamCalendar() {
  const db = useFirestore()
  const eventsRef = useMemo(() => db ? query(collection(db, 'examCalendar'), orderBy('date', 'asc')) : null, [db])
  const { data: dbEvents } = useCollection(eventsRef)

  const events = useMemo(() => {
    const list = dbEvents && dbEvents.length > 0 ? [...dbEvents] : [...staticEvents]
    return list.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
  }, [dbEvents])

  return (
    <div className="min-h-screen bg-secondary/10 pb-20">
      <Navbar />
      <main className="container mx-auto px-4 py-12 max-w-4xl">
        <header className="mb-12">
          <Badge className="bg-primary/20 text-primary border-none px-4 py-1 font-black text-[10px] uppercase tracking-widest mb-4">Schedule Tracker</Badge>
          <h1 className="text-5xl font-black font-headline tracking-tighter uppercase mb-2">Exam <span className="text-primary italic">Calendar</span></h1>
          <p className="text-muted-foreground font-bold">કોઈ પણ ડેટ મિસ ન કરો. એડમિટ કાર્ડ, રિઝલ્ટ અને પરીક્ષાની તારીખો ટ્રૅક કરો.</p>
        </header>

        <div className="space-y-6">
          {events.map((event) => (
            <Card key={event.id} className="border-none shadow-xl rounded-[2.5rem] overflow-hidden bg-background group hover:scale-[1.01] transition-all">
              <CardContent className="p-0 flex flex-col md:flex-row">
                <div className={cn(
                  "p-8 md:w-48 shrink-0 flex flex-col items-center justify-center text-center border-b md:border-b-0 md:border-r",
                  event.type === 'EXAM' ? 'bg-primary/10 text-primary' : 
                  event.type === 'DEADLINE' ? 'bg-red-50 text-red-600' : 
                  event.type === 'ADMIT_CARD' ? 'bg-yellow-50 text-yellow-600' :
                  'bg-blue-50 text-blue-600'
                )}>
                  <CalendarIcon className="h-8 w-8 mb-2" />
                  <p className="text-2xl font-black">{new Date(event.date).getDate()}</p>
                  <p className="text-[10px] font-black uppercase tracking-widest">{new Date(event.date).toLocaleString('default', { month: 'short' })}</p>
                </div>
                <div className="p-8 flex-grow flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div>
                    <Badge variant="outline" className="font-black text-[9px] uppercase tracking-widest mb-2 px-3 border-2">{event.type.replace('_', ' ')}</Badge>
                    <h3 className="text-xl font-black uppercase tracking-tight mb-2">{event.title}</h3>
                    <p className="text-sm font-bold text-muted-foreground flex items-center gap-2"><Info className="h-4 w-4 text-primary" /> {event.details}</p>
                  </div>
                  <Button variant="ghost" className="h-12 px-6 rounded-xl font-black text-[10px] uppercase tracking-widest group-hover:bg-primary group-hover:text-primary-foreground transition-all">
                    Set Reminder <Bell className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}
