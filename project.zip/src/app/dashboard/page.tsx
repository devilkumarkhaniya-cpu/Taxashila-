
"use client"

import React, { useState, useMemo } from 'react'
import { Navbar } from '@/components/navigation/navbar'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  Sparkles, BrainCircuit, Loader2, Target, Clock, Zap, BookOpen, Bookmark, FileText, ChevronRight, History, Award
} from 'lucide-react'
import { 
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip
} from 'recharts'
import { personalizedStudyRecommendations, type PersonalizedStudyRecommendationsOutput } from '@/ai/flows/personalized-study-recommendations'
import { useCollection, useFirestore, useUser } from '@/firebase'
import { collection, query, where, orderBy, limit } from 'firebase/firestore'
import { cn } from '@/lib/utils'

export default function Dashboard() {
  const { user } = useUser()
  const db = useFirestore()
  const [loadingAi, setLoadingAi] = useState(false)
  const [recommendations, setRecommendations] = useState<PersonalizedStudyRecommendationsOutput | null>(null)

  // Real Data Fetching
  const resultsRef = useMemo(() => (db && user ? query(collection(db, 'testResults'), where('userId', '==', user.uid), orderBy('completedAt', 'desc'), limit(10)) : null), [db, user])
  const bookmarksRef = useMemo(() => (db && user ? query(collection(db, 'bookmarks'), where('userId', '==', user.uid), limit(5)) : null), [db, user])

  const { data: testResults } = useCollection(resultsRef)
  const { data: bookmarks } = useCollection(bookmarksRef)

  const performanceData = useMemo(() => {
    if (!testResults || testResults.length === 0) return [
      { day: 'Mon', score: 65 }, { day: 'Tue', score: 72 }, { day: 'Wed', score: 68 },
      { day: 'Thu', score: 85 }, { day: 'Fri', score: 82 }, { day: 'Sat', score: 91 }, { day: 'Sun', score: 88 },
    ]
    return [...testResults].reverse().map(r => ({
      day: new Date(r.completedAt?.toDate()).toLocaleDateString('en-US', { weekday: 'short' }),
      score: r.accuracy
    }))
  }, [testResults])

  const stats = useMemo(() => {
    if (!testResults) return { accuracy: '0%', completed: 0 }
    const totalAcc = testResults.reduce((acc, r) => acc + (r.accuracy || 0), 0)
    return {
      accuracy: testResults.length > 0 ? `${Math.round(totalAcc / testResults.length)}%` : '0%',
      completed: testResults.length
    }
  }, [testResults])

  const getAiRecommendations = async () => {
    if (!testResults || testResults.length === 0) return
    setLoadingAi(true)
    try {
      const results = await personalizedStudyRecommendations({
        testResults: testResults.map(r => ({
          subject: r.testTitle.split(':')[0] || 'Mixed',
          topic: r.testTitle || 'General',
          score: r.score,
          maxScore: r.total,
          timeTakenSeconds: r.timeTaken,
          difficulty: 'Medium'
        })),
        studentGoals: "Focus on Gujarat Official Recruitment 2026"
      })
      setRecommendations(results)
    } catch (error) {
      console.error("Failed AI analysis", error)
    } finally {
      setLoadingAi(false)
    }
  }

  const userStats = [
    { title: "Notes Read", value: "18", icon: BookOpen, color: "text-blue-500", bg: "bg-blue-50" },
    { title: "Quizzes", value: stats.completed, icon: Target, color: "text-orange-500", bg: "bg-orange-50" },
    { title: "Accuracy", value: stats.accuracy, icon: Zap, color: "text-emerald-500", bg: "bg-emerald-50" },
    { title: "Study Time", value: "8.4h", icon: Clock, color: "text-purple-500", bg: "bg-purple-50" },
  ]

  return (
    <div className="min-h-screen bg-secondary/10 pb-20">
      <Navbar />
      <main className="container mx-auto px-4 py-12 max-w-7xl">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <h1 className="text-4xl font-black font-headline tracking-tighter uppercase">Student Hub</h1>
            <p className="text-muted-foreground font-bold mt-1">Ready for today's challenge, {user?.displayName?.split(' ')[0] || 'Ranker'}?</p>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" className="h-12 px-6 rounded-xl border-2 font-black uppercase text-[10px] tracking-widest">
              <History className="mr-2 h-4 w-4" /> History
            </Button>
            <Button className="h-12 px-8 rounded-xl font-black bg-primary text-primary-foreground uppercase text-[10px] tracking-widest shadow-xl shadow-primary/20">
              New Mock Test
            </Button>
          </div>
        </header>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          {userStats.map((stat) => (
            <Card key={stat.title} className="border-none shadow-xl rounded-[2.5rem] p-8 bg-background hover:scale-[1.02] transition-all">
              <div className={cn(stat.bg, "h-12 w-12 rounded-xl flex items-center justify-center mb-6")}>
                <stat.icon className={cn("h-6 w-6", stat.color)} />
              </div>
              <p className="text-3xl font-black font-headline mb-1">{stat.value}</p>
              <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">{stat.title}</p>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-10">
          <Card className="lg:col-span-2 border-none shadow-2xl rounded-[3rem] overflow-hidden bg-background">
            <CardHeader className="p-10 pb-0 flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-xl font-black uppercase tracking-widest">Performance Graph</CardTitle>
                <CardDescription className="font-bold text-sm">Weekly accuracy trends</CardDescription>
              </div>
              <Badge className="bg-primary text-primary-foreground font-black px-4 py-1 rounded-full text-[9px] uppercase">RANKER ANALYTICS</Badge>
            </CardHeader>
            <CardContent className="p-10 pt-6 h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={performanceData}>
                  <defs>
                    <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                  <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 700, fill: '#888' }} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 700, fill: '#888' }} />
                  <Tooltip contentStyle={{ borderRadius: '20px', border: 'none', boxShadow: '0 20px 50px rgba(0,0,0,0.1)', fontWeight: 800 }} />
                  <Area type="monotone" dataKey="score" stroke="hsl(var(--primary))" strokeWidth={4} fillOpacity={1} fill="url(#colorScore)" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="space-y-8">
            <Card className="border-none shadow-2xl rounded-[3rem] bg-foreground text-background overflow-hidden p-10 relative">
              <Sparkles className="absolute -top-4 -right-4 h-24 w-24 text-primary/10" />
              <CardTitle className="text-xl font-black uppercase tracking-widest flex items-center gap-3 mb-6">
                <BrainCircuit className="h-6 w-6 text-primary" /> AI Insights
              </CardTitle>
              {!recommendations ? (
                <div className="space-y-6">
                  <p className="text-sm font-medium text-zinc-400">Unlock a custom study strategy based on your recent activity.</p>
                  <Button onClick={getAiRecommendations} disabled={loadingAi || !testResults?.length} className="w-full h-14 bg-primary text-primary-foreground font-black rounded-xl text-sm shadow-xl shadow-primary/20">
                    {loadingAi ? <Loader2 className="animate-spin" /> : 'GENERATE STRATEGY'}
                  </Button>
                </div>
              ) : (
                <div className="space-y-6">
                  <p className="text-sm font-bold text-zinc-200 italic">"{recommendations.summary}"</p>
                  <div className="space-y-3">
                    {recommendations.recommendations.slice(0, 2).map((rec, i) => (
                      <div key={i} className="bg-zinc-800/50 rounded-2xl p-4 border border-zinc-700">
                        <p className="text-[9px] font-black text-primary uppercase tracking-widest mb-1">{rec.subject}</p>
                        <p className="text-xs font-bold text-zinc-100">{rec.topic}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </Card>

            <Card className="border-none shadow-2xl rounded-[3rem] bg-background p-10">
              <div className="flex items-center justify-between mb-8">
                <CardTitle className="text-xl font-black uppercase tracking-widest flex items-center gap-3">
                  <Bookmark className="h-5 w-5 text-primary" /> Saved Items
                </CardTitle>
              </div>
              <div className="space-y-4">
                {bookmarks && bookmarks.length > 0 ? bookmarks.map((item, i) => (
                  <div key={i} className="flex items-center gap-4 group cursor-pointer">
                    <div className="h-10 w-10 rounded-xl bg-secondary flex items-center justify-center shrink-0">
                      <FileText className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div className="flex-grow min-w-0">
                      <p className="font-black text-sm truncate">{item.title}</p>
                      <p className="text-[9px] font-black text-primary uppercase tracking-widest">{item.resourceType}</p>
                    </div>
                    <ChevronRight className="h-4 w-4 text-zinc-300" />
                  </div>
                )) : (
                  <div className="py-8 text-center">
                    <p className="text-[10px] font-black uppercase text-muted-foreground">No saved items yet</p>
                  </div>
                )}
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
