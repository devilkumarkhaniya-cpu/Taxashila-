'use client';

import React, { useState, useMemo } from 'react';
import { Navbar } from '@/components/navigation/navbar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { useCollection, useFirestore } from '@/firebase';
import { collection, addDoc, deleteDoc, doc, serverTimestamp, query, orderBy, limit } from 'firebase/firestore';
import { Loader2, Trash2, LayoutDashboard, Link as LinkIcon, Zap, TrendingUp, Users, MousePointer2, Lock, Key, Mail, Newspaper, Calendar } from 'lucide-react';
import { masterSyllabus } from '@/app/pdfs/textbook-data';
import { useToast } from '@/hooks/use-toast';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const MASTER_PASSWORD = 'Devil@01754';

export default function AdminPanel() {
  const db = useFirestore();
  const { toast } = useToast();
  
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Data fetching
  const materialsQuery = useMemo(() => (db ? query(collection(db, 'studyMaterials'), orderBy('createdAt', 'desc')) : null), [db]);
  const { data: materials, loading: materialsLoading } = useCollection(materialsQuery);

  const newsQuery = useMemo(() => (db ? query(collection(db, 'examNews'), orderBy('createdAt', 'desc')) : null), [db]);
  const { data: newsItems, loading: newsLoading } = useCollection(newsQuery);

  const analyticsQuery = useMemo(() => (db ? query(collection(db, 'analytics'), orderBy('timestamp', 'desc'), limit(100)) : null), [db]);
  const { data: analyticsData, loading: analyticsLoading } = useCollection(analyticsQuery);

  const subscribersQuery = useMemo(() => (db ? query(collection(db, 'subscribers'), orderBy('subscribedAt', 'desc')) : null), [db]);
  const { data: subscribers, loading: subscribersLoading } = useCollection(subscribersQuery);

  // States for new entries
  const [newMaterial, setNewMaterial] = useState({
    title: '', subject: '', description: '', content: '', icon: '📚', size: 'External', type: 'LINK'
  });

  const [newNews, setNewNews] = useState({
    title: '', description: '', details: '', category: '', applyLink: '', lastDate: ''
  });

  const handlePasswordAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === MASTER_PASSWORD) {
      setIsAuthorized(true);
      toast({ title: "Authorized", description: "Welcome back, Admin." });
    } else {
      toast({ title: "Access Denied", description: "Incorrect password.", variant: "destructive" });
    }
  };

  const handleAddMaterial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!db) return;
    if (!newMaterial.title || !newMaterial.subject || !newMaterial.content) {
      toast({ title: "Missing Fields", variant: "destructive" });
      return;
    }
    setIsSubmitting(true);
    const dataToSave = { ...newMaterial, createdAt: serverTimestamp() };
    addDoc(collection(db, 'studyMaterials'), dataToSave)
      .then(() => {
        toast({ title: "Material Published!" });
        setNewMaterial({ title: '', subject: '', description: '', content: '', icon: '📚', size: 'External', type: 'LINK' });
      })
      .catch(async (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({ path: 'studyMaterials', operation: 'create', requestResourceData: dataToSave }));
      })
      .finally(() => setIsSubmitting(false));
  };

  const handleAddNews = (e: React.FormEvent) => {
    e.preventDefault();
    if (!db) return;
    if (!newNews.title || !newNews.category || !newNews.applyLink) {
      toast({ title: "Missing Fields", variant: "destructive" });
      return;
    }
    setIsSubmitting(true);
    const dataToSave = { ...newNews, createdAt: serverTimestamp() };
    addDoc(collection(db, 'examNews'), dataToSave)
      .then(() => {
        toast({ title: "Job Alert Published!" });
        setNewNews({ title: '', description: '', details: '', category: '', applyLink: '', lastDate: '' });
      })
      .catch(async (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({ path: 'examNews', operation: 'create', requestResourceData: dataToSave }));
      })
      .finally(() => setIsSubmitting(false));
  };

  const handleDelete = (col: string, id: string) => {
    if (!db || !confirm('Confirm deletion?')) return;
    deleteDoc(doc(db, col, id))
      .then(() => toast({ title: "Deleted Successfully" }))
      .catch(async (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({ path: `${col}/${id}`, operation: 'delete' }));
      });
  };

  const stats = useMemo(() => {
    if (!analyticsData) return { totalViews: 0, materialClicks: 0 };
    const views = analyticsData.filter(a => !a.path?.includes('/click/')).length;
    const clicks = analyticsData.filter(a => a.path?.includes('/click/')).length;
    return { totalViews: views, materialClicks: clicks };
  }, [analyticsData]);

  if (!isAuthorized) {
    return (
      <div className="min-h-screen bg-secondary/10 flex flex-col items-center justify-center p-4">
        <Navbar />
        <Card className="max-w-md w-full border-4 border-foreground rounded-[2.5rem] shadow-2xl overflow-hidden mt-10">
          <div className="bg-foreground text-background p-10 text-center relative overflow-hidden">
             <div className="absolute top-0 right-0 p-8 opacity-10"><Lock className="h-32 w-32" /></div>
             <div className="h-16 w-16 bg-primary rounded-2xl flex items-center justify-center mx-auto mb-6 rotate-12 relative z-10">
               <Key className="h-8 w-8 text-foreground" />
             </div>
             <h2 className="text-3xl font-black font-headline uppercase tracking-tighter relative z-10">Master Access</h2>
             <p className="text-zinc-400 font-bold text-xs mt-2 uppercase tracking-widest relative z-10">Enter Admin Key</p>
          </div>
          <CardContent className="p-10">
            <form onSubmit={handlePasswordAuth} className="space-y-6">
              <Input type="password" placeholder="••••••••" className="h-14 rounded-xl border-2 text-center text-xl font-bold" value={passwordInput} onChange={(e) => setPasswordInput(e.target.value)} required />
              <Button type="submit" className="w-full h-16 bg-primary text-primary-foreground font-black text-xl rounded-2xl border-4 border-foreground shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:translate-x-1 hover:translate-y-1 hover:shadow-none transition-all">AUTHORIZE</Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-secondary/10 pb-20">
      <Navbar />
      <main className="container mx-auto px-4 py-12 max-w-7xl">
        <div className="flex items-center justify-between mb-12">
          <h1 className="text-4xl md:text-5xl font-black font-headline uppercase tracking-tighter">Admin Dashboard</h1>
          <LayoutDashboard className="h-10 w-10 text-primary" />
        </div>

        <Tabs defaultValue="publisher" className="space-y-8">
          <TabsList className="bg-background border-4 border-foreground p-1 h-14 rounded-2xl w-full flex overflow-x-auto overflow-y-hidden scrollbar-hide">
            <TabsTrigger value="publisher" className="rounded-xl px-6 font-black text-[10px] uppercase tracking-widest shrink-0"><Zap className="h-4 w-4 mr-2" /> Materials</TabsTrigger>
            <TabsTrigger value="news" className="rounded-xl px-6 font-black text-[10px] uppercase tracking-widest shrink-0"><Newspaper className="h-4 w-4 mr-2" /> Exam News</TabsTrigger>
            <TabsTrigger value="analytics" className="rounded-xl px-6 font-black text-[10px] uppercase tracking-widest shrink-0"><TrendingUp className="h-4 w-4 mr-2" /> Analytics</TabsTrigger>
            <TabsTrigger value="subscribers" className="rounded-xl px-6 font-black text-[10px] uppercase tracking-widest shrink-0"><Mail className="h-4 w-4 mr-2" /> Subs</TabsTrigger>
          </TabsList>

          <TabsContent value="publisher" className="space-y-8">
            <div className="grid md:grid-cols-2 gap-8">
              <Card className="border-4 border-foreground rounded-[2.5rem] p-8 shadow-xl bg-background">
                <CardTitle className="text-xl font-black mb-6 uppercase flex items-center gap-2"><LinkIcon className="h-5 w-5 text-primary" /> Publish Material Link</CardTitle>
                <div className="space-y-4">
                  <Label>Subject</Label>
                  <select value={newMaterial.subject} onChange={e => setNewMaterial({...newMaterial, subject: e.target.value})} className="h-12 w-full border-2 rounded-xl px-3 font-bold">
                    <option value="">Select Category</option>
                    {masterSyllabus.map(s => <option key={s.id} value={s.title}>{s.title}</option>)}
                  </select>
                  <Input placeholder="Material Title" value={newMaterial.title} onChange={e => setNewMaterial({...newMaterial, title: e.target.value})} className="border-2 rounded-xl font-bold" />
                  <Input placeholder="Drive URL" value={newMaterial.content} onChange={e => setNewMaterial({...newMaterial, content: e.target.value})} className="border-2 rounded-xl font-bold" />
                  <Button onClick={handleAddMaterial} disabled={isSubmitting} className="w-full h-14 font-black border-4 border-foreground shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">PUBLISH NOW</Button>
                </div>
              </Card>
              <Card className="border-4 border-foreground rounded-[2.5rem] p-8 bg-background">
                <CardTitle className="text-xl font-black mb-6 uppercase">Published Library</CardTitle>
                <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                  {materialsLoading ? <Loader2 className="animate-spin h-6 w-6 mx-auto" /> : materials?.map(m => (
                    <div key={m.id} className="p-4 bg-secondary/20 rounded-xl flex justify-between items-center border-2">
                      <div className="truncate"><p className="font-black text-sm truncate">{m.title}</p><p className="text-[10px] uppercase font-bold text-muted-foreground">{m.subject}</p></div>
                      <Button variant="destructive" size="icon" onClick={() => handleDelete('studyMaterials', m.id)} className="border-2 border-foreground"><Trash2 className="h-4 w-4" /></Button>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="news" className="space-y-8">
            <div className="grid md:grid-cols-2 gap-8">
              <Card className="border-4 border-foreground rounded-[2.5rem] p-8 shadow-xl bg-background">
                <CardTitle className="text-xl font-black mb-6 uppercase flex items-center gap-2"><Newspaper className="h-5 w-5 text-primary" /> Post Job Alert</CardTitle>
                <div className="space-y-4">
                  <Input placeholder="Job Title (e.g. Police Constable 2024)" value={newNews.title} onChange={e => setNewNews({...newNews, title: e.target.value})} className="font-bold border-2" />
                  <Input placeholder="Exam Category (e.g. Police, GPSC)" value={newNews.category} onChange={e => setNewNews({...newNews, category: e.target.value})} className="font-bold border-2" />
                  <Input placeholder="Short Summary" value={newNews.description} onChange={e => setNewNews({...newNews, description: e.target.value})} className="font-bold border-2" />
                  <Textarea placeholder="Full Details (Requirements, Fees, etc.)" value={newNews.details} onChange={e => setNewNews({...newNews, details: e.target.value})} className="font-bold border-2" />
                  <div className="grid grid-cols-2 gap-4">
                    <Input type="date" value={newNews.lastDate} onChange={e => setNewNews({...newNews, lastDate: e.target.value})} className="font-bold border-2" />
                    <Input placeholder="Apply URL" value={newNews.applyLink} onChange={e => setNewNews({...newNews, applyLink: e.target.value})} className="font-bold border-2" />
                  </div>
                  <Button onClick={handleAddNews} disabled={isSubmitting} className="w-full h-14 font-black bg-primary border-4 border-foreground shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">POST JOB ALERT</Button>
                </div>
              </Card>
              <Card className="border-4 border-foreground rounded-[2.5rem] p-8 bg-background">
                <CardTitle className="text-xl font-black mb-6 uppercase">Manage News</CardTitle>
                <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                  {newsLoading ? <Loader2 className="animate-spin h-6 w-6 mx-auto" /> : newsItems?.map(n => (
                    <div key={n.id} className="p-4 bg-secondary/20 rounded-xl flex justify-between items-center border-2">
                      <div className="truncate"><p className="font-black text-sm truncate">{n.title}</p><p className="text-[10px] uppercase font-bold text-muted-foreground">{n.category}</p></div>
                      <Button variant="destructive" size="icon" onClick={() => handleDelete('examNews', n.id)} className="border-2 border-foreground"><Trash2 className="h-4 w-4" /></Button>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-8">
             <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: "Total Page Views", value: stats.totalViews, icon: Users, color: "text-blue-600", bg: "bg-blue-100" },
                { label: "Material Clicks", value: stats.materialClicks, icon: MousePointer2, color: "text-green-600", bg: "bg-green-100" },
                { label: "Live News", value: newsItems?.length || 0, icon: Newspaper, color: "text-primary", bg: "bg-primary/20" },
                { label: "Active Subs", value: subscribers?.length || 0, icon: Mail, color: "text-purple-600", bg: "bg-purple-100" },
              ].map((stat, i) => (
                <Card key={i} className="p-8 border-4 border-foreground shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] rounded-[2.5rem] bg-background">
                  <div className={`${stat.bg} p-3 w-fit rounded-xl mb-4 border-2 border-foreground`}><stat.icon className={`h-6 w-6 ${stat.color}`} /></div>
                  <div className="text-4xl font-black font-headline mb-1">{stat.value}</div>
                  <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">{stat.label}</p>
                </Card>
              ))}
            </div>
            <Card className="border-4 border-foreground rounded-[2.5rem] shadow-2xl overflow-hidden bg-background">
              <CardHeader className="bg-foreground text-background"><CardTitle className="text-lg uppercase">Recent Visitor Logs</CardTitle></CardHeader>
              <div className="divide-y divide-foreground/10 max-h-[500px] overflow-y-auto">
                {analyticsLoading ? <div className="p-10 text-center"><Loader2 className="animate-spin h-8 w-8 mx-auto" /></div> : analyticsData?.map((log, i) => (
                  <div key={i} className="p-6 flex items-center justify-between hover:bg-secondary/10 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className={`h-10 w-10 rounded-full flex items-center justify-center border-2 ${log.path?.includes('/click/') ? 'bg-green-100 border-green-600' : 'bg-blue-100 border-blue-600'}`}>
                        {log.path?.includes('/click/') ? <MousePointer2 className="h-4 w-4 text-green-600" /> : <Users className="h-4 w-4 text-blue-600" />}
                      </div>
                      <div>
                        <p className="text-sm font-black truncate max-w-[200px] md:max-w-md">{log.path?.replace(/%20/g, ' ')}</p>
                        <p className="text-[10px] font-bold text-muted-foreground">{log.timestamp?.toDate ? log.timestamp.toDate().toLocaleString() : 'Just now'}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="hidden md:flex text-[8px] font-black uppercase tracking-widest px-3 border-2">
                      {log.device?.includes('Mobile') ? 'Mobile' : 'Desktop'}
                    </Badge>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="subscribers">
            <Card className="border-4 border-foreground rounded-[2.5rem] shadow-2xl overflow-hidden bg-background">
              <CardHeader className="bg-foreground text-background"><CardTitle className="text-lg uppercase">Mailing List</CardTitle></CardHeader>
              <div className="divide-y divide-foreground/10 max-h-[500px] overflow-y-auto">
                {subscribersLoading ? <div className="p-10 text-center"><Loader2 className="animate-spin h-8 w-8 mx-auto" /></div> : subscribers?.map((sub, i) => (
                  <div key={i} className="p-6 flex items-center justify-between hover:bg-secondary/10">
                    <div className="flex items-center gap-4"><Mail className="h-5 w-5 text-primary" /><div><p className="text-sm font-black">{sub.email}</p><p className="text-[10px] text-muted-foreground font-bold">Joined: {sub.subscribedAt?.toDate ? sub.subscribedAt.toDate().toLocaleString() : 'Recent'}</p></div></div>
                    <Badge variant="secondary" className="text-[8px] font-black px-4 border-2 border-foreground">STUDENT</Badge>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}