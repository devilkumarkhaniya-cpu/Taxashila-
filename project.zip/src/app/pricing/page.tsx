
"use client"

import React from 'react'
import { Navbar } from '@/components/navigation/navbar'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Check, ShieldCheck, Zap, Star, Shield } from 'lucide-react'
import { cn } from '@/lib/utils'
import Link from 'next/link'

export default function Pricing() {
  const plans = [
    {
      name: "Starter",
      price: "0",
      description: "Perfect for testing the waters",
      features: [
        "10 Free Mock Tests",
        "Limited PDF Access",
        "Basic Performance Data",
        "Daily Current Affairs"
      ],
      cta: "Join Free",
      popular: false,
      href: "/dashboard"
    },
    {
      name: "Pro Learner",
      price: "499",
      description: "Most popular choice for serious aspirants",
      features: [
        "Unlimited Mock Tests",
        "All Premium PDFs",
        "AI Performance Analysis",
        "Sectional Topic Tests",
        "Ad-free Experience",
        "Doubt Support"
      ],
      cta: "Upgrade to Pro",
      popular: true,
      href: "#"
    },
    {
      name: "Ultimate Ranker",
      price: "999",
      description: "Everything you need to secure top rank",
      features: [
        "Everything in Pro",
        "1-on-1 Mentorship Session",
        "Priority Doubt Solving",
        "Full Length Mock Predictor",
        "Offline Centers Discount"
      ],
      cta: "Go Ultimate",
      popular: false,
      href: "#"
    }
  ]

  return (
    <div className="min-h-screen bg-secondary/10 pb-20">
      <Navbar />
      <main className="container mx-auto px-4 py-20 max-w-7xl">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-1 rounded-full bg-primary text-primary-foreground text-[10px] font-black uppercase tracking-[0.2em] mb-4">
            Invest in Excellence
          </div>
          <h1 className="text-4xl md:text-7xl font-black font-headline mb-6 tracking-tighter uppercase">
            Choose Your <span className="text-primary">Ranker Plan</span>
          </h1>
          <p className="text-muted-foreground text-xl max-w-2xl mx-auto font-medium">
            Join 50,000+ students who are already using Takshashila to achieve their dreams.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan) => (
            <Card key={plan.name} className={cn(
              "relative flex flex-col border-none shadow-2xl transition-all duration-500 rounded-[3rem] overflow-hidden",
              plan.popular ? 'ring-8 ring-primary/20 scale-105 z-10' : 'bg-background hover:scale-[1.02]'
            )}>
              {plan.popular && (
                <div className="absolute top-0 left-0 right-0 h-2 bg-primary" />
              )}
              <CardHeader className="pt-12 text-center">
                {plan.popular && (
                  <Badge className="bg-primary text-primary-foreground mx-auto mb-4 font-black text-[10px] px-4">MOST POPULAR</Badge>
                )}
                <CardTitle className="text-2xl font-black font-headline uppercase tracking-tighter">{plan.name}</CardTitle>
                <div className="mt-6 flex items-center justify-center gap-1">
                  <span className="text-lg font-black text-muted-foreground">₹</span>
                  <span className="text-7xl font-black font-headline tracking-tighter">{plan.price}</span>
                  <div className="text-left">
                    <p className="text-[10px] font-black text-muted-foreground uppercase leading-none">INR</p>
                    <p className="text-[10px] font-black text-muted-foreground uppercase leading-none mt-1">/ MONTH</p>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground font-bold mt-6 px-4">{plan.description}</p>
              </CardHeader>
              <CardContent className="flex-grow pt-10 px-8">
                <ul className="space-y-5">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-4 text-sm font-bold">
                      <div className="mt-0.5 h-6 w-6 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                        <Check className="h-3.5 w-3.5 text-primary" />
                      </div>
                      <span className="text-zinc-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter className="pb-12 pt-8 px-10">
                <Button asChild className={cn(
                  "w-full h-16 text-xl font-black rounded-2xl shadow-xl transition-all uppercase tracking-widest",
                  plan.popular 
                    ? 'bg-primary text-primary-foreground hover:bg-primary/90 shadow-primary/20' 
                    : 'bg-foreground text-background hover:bg-zinc-800'
                )}>
                  <Link href={plan.href}>{plan.cta}</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="mt-24 p-12 bg-foreground text-background rounded-[3rem] shadow-2xl relative overflow-hidden">
           <div className="absolute top-0 right-0 p-12 opacity-5">
             <Shield className="h-64 w-64 text-primary" />
           </div>
           <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-12">
              <div className="max-w-xl">
                 <h2 className="text-3xl md:text-5xl font-black font-headline mb-6 leading-tight tracking-tighter">STUDENT SUCCESS GUARANTEE</h2>
                 <p className="text-zinc-400 text-lg font-medium leading-relaxed mb-8">
                   We are so confident in our structure that if you complete 90% of our curriculum and don't see a rank improvement, we will refund your last month's subscription. No questions asked.
                 </p>
                 <div className="flex items-center gap-6">
                   <div className="flex items-center gap-2">
                     <ShieldCheck className="h-6 w-6 text-primary" />
                     <span className="text-xs font-black uppercase tracking-widest">Safe Payment</span>
                   </div>
                   <div className="flex items-center gap-2">
                     <Star className="h-6 w-6 text-primary" />
                     <span className="text-xs font-black uppercase tracking-widest">Top Rated Platform</span>
                   </div>
                 </div>
              </div>
              <div className="shrink-0 text-center">
                 <p className="text-sm font-black text-primary mb-2 uppercase tracking-widest">Join the Elite</p>
                 <p className="text-6xl font-black font-headline mb-8">50K+</p>
                 <p className="text-xs font-black text-zinc-500 uppercase tracking-widest">Active Aspirants</p>
              </div>
           </div>
        </div>
      </main>
    </div>
  )
}
