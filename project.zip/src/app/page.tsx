
'use client';

import React, { useMemo } from 'react'
import { Navbar } from '@/components/navigation/navbar'
import { Newsletter } from '@/components/home/newsletter'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  TrendingUp, ArrowRight, BrainCircuit, ScrollText, Newspaper, Timer, Users, BookOpen, Award, Zap
} from 'lucide-react'
import Link from 'next/link'
import { useCollection, useFirestore } from '@/firebase'
import { collection, query, orderBy, limit } from 'firebase/firestore'
import { cn } from '@/lib/utils'
import Image from 'next/image'

export default function Home() {
  const db = useFirestore();
  const newsQuery = useMemo(() => (db ? query(collection(db, 'examNews'), orderBy('createdAt', 'desc'), limit(3)) : null), [db]);
  const { data: dbLatestNews } = useCollection(newsQuery);

  const staticNews = [
    { id: 'static-1', title: 'GPSC Class 1-2 Recruitment 2024', category: 'GPSC', lastDate: '31-08-2024' },
    { id: 'static-2', title: 'Police Constable (12,000+ Vacancies)', category: 'Police', lastDate: '15-09-2024' },
    { id: 'static-3', title: 'GSSSB Junior Clerk Exam Schedule', category: 'GSSSB', lastDate: 'Immediate' }
  ];

  const newsToShow = dbLatestNews && dbLatestNews.length > 0 ? dbLatestNews : staticNews;

  const quickCategories = [
    { id: 'constitution', name: 'Polity', icon: ScrollText, color: 'text-orange-500', bg: 'bg-orange-50', desc: 'Indian Constitution' },
    { id: 'aptitude', name: 'Maths', icon: TrendingUp, color: 'text-blue-500', bg: 'bg-blue-50', desc: 'Quant & DI' },
    { id: 'reasoning', name: 'Reasoning', icon: BrainCircuit, color: 'text-purple-500', bg: 'bg-purple-50', desc: 'Logic Puzzles' },
    { id: 'current-affairs', name: 'Current Affairs', icon: Newspaper, color: 'text-emerald-500', bg: 'bg-emerald-50', desc: 'Daily Updates' },
  ]

  const trustStats = [
    { label: "Active Aspirants", value: "50,000+", icon: Users, color: "text-blue-600" },
    { label: "Premium PDFs", value: "2,000+", icon: BookOpen, color: "text-orange-600" },
    { label: "Mock Tests", value: "500+", icon: Award, color: "text-emerald-600" },
    { label: "Daily Updates", value: "100%", icon: Zap, color: "text-primary" },
  ]

  return (
    <div className="flex flex-col min-h-screen font-body select-none">
      <Navbar />
      <main className="flex-grow">
        
        {/* Optimized Hero Section */}
        <section className="relative pt-12 pb-16 lg:pt-20 lg:pb-24 overflow-hidden bg-gradient-to-b from-primary/5 via-background to-background">
          <div className="container mx-auto px-4 relative z-10">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="text-center lg:text-left space-y-6 animate-in fade-in slide-in-from-left duration-700">
                <Badge className="px-4 py-1.5 rounded-full bg-primary/20 text-foreground border-none font-black uppercase tracking-widest text-[10px]">
                  🚀 Gujarat's #1 Learning Platform
                </Badge>
                <h1 className="text-4xl lg:text-6xl font-black leading-[1.1] font-headline text-foreground tracking-tighter">
                  Crack GPSC, GSSSB & <br />
                  <span className="text-primary italic">Competitive Exams</span>
                </h1>
                <p className="text-lg text-muted-foreground font-medium max-w-xl mx-auto lg:mx-0 leading-relaxed">
                  Smart preparation with High-Quality Practice, Premium Notes, and Daily AI Performance Analysis.
                </p>
                
                <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                  <Button asChild size="lg" className="h-14 px-8 text-lg font-black rounded-2xl shadow-xl shadow-primary/20 group bg-primary text-primary-foreground transition-transform hover:scale-105">
                    <Link href="/mock-tests">
                      Start Learning Free <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="lg" className="h-14 px-8 text-lg font-black rounded-2xl border-2 hover:bg-secondary">
                    <Link href="/pdfs">Browse Notes</Link>
                  </Button>
                </div>
              </div>

              <div className="relative hidden lg:block animate-in fade-in slide-in-from-right duration-700">
                <div className="absolute -top-10 -right-10 w-72 h-72 bg-primary/20 blur-[100px] rounded-full opacity-50" />
                <div className="relative z-10 rounded-[3rem] overflow-hidden shadow-2xl border-[8px] border-white dark:border-zinc-800 rotate-1 premium-shadow transition-transform hover:rotate-0 duration-700">
                  <Image 
                    src="https://picsum.photos/seed/taksha-v2/1000/750" 
                    alt="Success" 
                    width={1000} 
                    height={750}
                    className="object-cover"
                    data-ai-hint="student success"
                    priority
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Statistics Section */}
        <section className="py-10 bg-background border-y">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {trustStats.map((stat, i) => (
                <div key={i} className="flex flex-col items-center text-center space-y-2 p-4 rounded-[1.5rem] hover:bg-secondary/20 transition-all">
                  <stat.icon className={cn("h-6 w-6 mb-1", stat.color)} />
                  <div className="text-2xl font-black font-headline tracking-tighter">{stat.value}</div>
                  <div className="text-[9px] font-black text-muted-foreground uppercase tracking-widest">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Subject Cards Section */}
        <section className="py-20 bg-background">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center justify-between mb-12 gap-4">
              <div className="text-center md:text-left">
                <h2 className="text-3xl font-black font-headline uppercase tracking-tighter">સંપૂર્ણ પરીક્ષા લક્ષી મટીરીયલ</h2>
                <p className="text-muted-foreground font-bold mt-2">Focused study paths for targetted results.</p>
              </div>
              <Button variant="ghost" className="font-bold gap-2 text-primary" asChild>
                <Link href="/pdfs">View Full Syllabus <ArrowRight className="h-4 w-4" /></Link>
              </Button>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              {quickCategories.map((cat) => (
                <Link key={cat.id} href={`/pdfs#${cat.id}`} className="group">
                  <Card className="border-none bg-secondary/30 p-8 rounded-[2.5rem] transition-all hover:translate-y-[-4px] hover:shadow-xl hover:bg-background h-full flex flex-col items-center text-center">
                    <div className={cn("h-12 w-12 rounded-xl flex items-center justify-center mb-6 group-hover:rotate-12 transition-all shadow-sm", cat.bg)}>
                      <cat.icon className={cn("h-6 w-6", cat.color)} />
                    </div>
                    <h3 className="text-xl font-black mb-2 tracking-tight">{cat.name}</h3>
                    <p className="text-[10px] text-muted-foreground font-bold leading-relaxed">{cat.desc}</p>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Latest Exam News Section */}
        <section className="py-20 bg-secondary/10">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between mb-12">
              <div>
                <h2 className="text-3xl font-black font-headline tracking-tighter uppercase">Latest Job Alerts</h2>
                <p className="text-muted-foreground font-bold">New recruitment notifications directly from OJAS & Govt.</p>
              </div>
              <Button asChild variant="outline" className="h-12 border-2 rounded-xl font-black px-6">
                <Link href="/exam-news">SEE ALL JOBS</Link>
              </Button>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {newsToShow.map((news) => (
                <Card key={news.id} className="border-none bg-background rounded-[2rem] p-8 shadow-lg transition-all hover:shadow-xl hover:translate-y-[-2px] flex flex-col">
                  <Badge className="mb-4 bg-primary/10 text-primary border-none font-black text-[8px] tracking-widest uppercase px-3 py-1 w-fit">{news.category}</Badge>
                  <h3 className="text-xl font-black mb-4 leading-tight tracking-tight flex-grow">{news.title}</h3>
                  <div className="flex items-center justify-between mt-auto pt-4 border-t">
                    <span className="text-[9px] font-black text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                      <Timer className="h-3 w-3" /> Ends: {news.lastDate}
                    </span>
                    <Button variant="ghost" size="sm" className="font-black text-primary p-0 h-auto hover:bg-transparent group" asChild>
                      <Link href="/exam-news">Details <ArrowRight className="ml-1 h-3 w-3 group-hover:translate-x-1 transition-transform" /></Link>
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <Newsletter />
      </main>

      <footer className="bg-foreground text-background py-16 border-t-8 border-primary">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-12 text-center md:text-left">
            <div className="md:col-span-2">
              <span className="text-3xl font-black font-headline uppercase tracking-tighter">
                Taksha<span className="text-primary italic">shila</span>
              </span>
              <p className="mt-4 text-zinc-400 font-medium max-w-sm leading-relaxed mx-auto md:mx-0 text-sm">
                Gujarat's leading smart-preparation platform. We provide premium resources, AI analytics, and daily mock tests to ensure your success.
              </p>
            </div>
            <div className="space-y-4">
              <h4 className="text-xs font-black uppercase tracking-widest text-primary">Resources</h4>
              <nav className="flex flex-col gap-3 text-[10px] font-black uppercase tracking-widest">
                <Link href="/pdfs" className="hover:text-primary transition-colors">Study Vault</Link>
                <Link href="/mock-tests" className="hover:text-primary transition-colors">Mock Tests</Link>
                <Link href="/exam-news" className="hover:text-primary transition-colors">Job Alerts</Link>
              </nav>
            </div>
            <div className="space-y-4">
              <h4 className="text-xs font-black uppercase tracking-widest text-primary">Admin</h4>
              <nav className="flex flex-col gap-3 text-[10px] font-black uppercase tracking-widest">
                <Link href="/admin" className="hover:text-primary transition-colors">Admin Panel</Link>
                <Link href="/dashboard" className="hover:text-primary transition-colors">Student Hub</Link>
              </nav>
            </div>
          </div>
          <div className="mt-16 pt-8 border-t border-zinc-800 text-[9px] font-bold text-zinc-500 text-center tracking-widest uppercase">
            © 2024 TAKSHASHILA EDTECH. BUILT FOR RANKERS. GUJARAT, INDIA.
          </div>
        </div>
      </footer>
    </div>
  )
}
