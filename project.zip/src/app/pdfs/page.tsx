
'use client';

import React, { useState, useMemo } from 'react';
import { Navbar } from '@/components/navigation/navbar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Search, ExternalLink, ShieldCheck, Loader2, Bookmark, FileText, Share2, Eye
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useCollection, useFirestore } from '@/firebase';
import { collection, query, orderBy, addDoc, serverTimestamp } from 'firebase/firestore';
import { masterSyllabus } from './textbook-data';
import { useToast } from '@/hooks/use-toast';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

export default function PdfLibrary() {
  const [searchQuery, setSearchQuery] = useState("");
  const db = useFirestore();
  const { toast } = useToast();
  
  const driveLinks: Record<string, string> = {
    constitution: "https://drive.google.com/drive/folders/1aU590uzSY9nOo8k9U94qjfNVpGEdP2lk",
    reasoning: "https://drive.google.com/drive/folders/1UY2KDL2Zme3-hu1EwW061qif0tYIUYBQ",
    aptitude: "https://drive.google.com/drive/folders/1d4Ivp1SdxzNmbKQ_citHsvj5TY3Nqyrg",
    'current-affairs': "https://drive.google.com/drive/folders/1wCNLVq6XLRwM_USw7vj8qWk9Cu2ka7yK",
    comprehension: "https://drive.google.com/drive/folders/1OaJHt80IuLUuXgWH-L-CpZZCnmG6Un1L",
  };

  const materialsQuery = useMemo(() => (db ? query(collection(db, 'studyMaterials'), orderBy('createdAt', 'desc')) : null), [db]);
  const { data: dbMaterials } = useCollection(materialsQuery);

  const filteredSyllabus = masterSyllabus.filter(subject => 
    subject.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const logClick = (title: string) => {
    if (!db) return;
    const dataToSave = {
      path: `/click/material/${title}`,
      timestamp: serverTimestamp(),
      device: typeof window !== 'undefined' ? window.navigator.userAgent : 'unknown'
    };
    addDoc(collection(db, 'analytics'), dataToSave).catch(err => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({ path: 'analytics', operation: 'create', requestResourceData: dataToSave }));
    });
  };

  const handleReadClick = (url: string, title: string) => {
    if (url && url.startsWith('http')) {
      logClick(title);
      window.open(url, '_blank');
    }
  };

  return (
    <div className="min-h-screen bg-secondary/5 font-body pb-24 no-print select-none">
      <Navbar />
      
      <main className="container mx-auto px-4 py-16 max-w-7xl">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-16 mb-24">
          <div className="max-w-3xl space-y-8">
            <Badge className="bg-primary/20 text-foreground border-none px-6 py-2 uppercase font-black text-[11px] tracking-[0.3em] rounded-full">Digital Vault 2.0</Badge>
            <h1 className="text-6xl lg:text-9xl font-black font-headline tracking-tighter uppercase leading-[0.9]">
              Study <br />
              <span className="text-primary italic">Materials</span>
            </h1>
            <p className="text-2xl text-muted-foreground font-bold leading-relaxed">Access 2,000+ premium resources, books and notes curated specifically for official exams.</p>
          </div>
          <div className="relative w-full lg:w-[450px]">
            <Search className="absolute left-8 top-1/2 -translate-y-1/2 h-6 w-6 text-muted-foreground" />
            <Input 
              placeholder="Search for subjects or topics..." 
              className="pl-20 h-20 rounded-[2.5rem] shadow-2xl border-none bg-background text-xl font-bold"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          {filteredSyllabus.map((subject) => {
            const subjectDbMaterials = dbMaterials?.filter(m => m.subject === subject.title) || [];
            const hasMasterLink = !!driveLinks[subject.id];

            return (
              <Card key={subject.id} id={subject.id} className="border-none shadow-2xl rounded-[4rem] overflow-hidden bg-background group scroll-mt-24 transition-all hover:translate-y-[-10px] hover:shadow-primary/5">
                <CardHeader className="p-12 bg-foreground text-background flex flex-row items-center justify-between border-b border-white/10">
                  <div className="flex items-center gap-8">
                    <div className={cn("h-20 w-20 rounded-[2rem] flex items-center justify-center transition-all group-hover:rotate-12 shadow-inner", subject.color)}>
                      <subject.icon className="h-10 w-10" />
                    </div>
                    <div>
                      <h3 className="text-3xl font-black font-headline tracking-tighter uppercase leading-tight">{subject.title}</h3>
                      <p className="text-[11px] font-black text-zinc-400 uppercase tracking-[0.3em] mt-1">{subjectDbMaterials.length + (hasMasterLink ? 1 : 0)} Active Modules</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="h-14 w-14 rounded-2xl text-zinc-500 hover:text-primary transition-all bg-zinc-800/50 hover:bg-zinc-800"><Bookmark className="h-6 w-6" /></Button>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="divide-y divide-secondary/50">
                    {hasMasterLink && (
                      <div className="p-10 hover:bg-secondary/30 transition-all flex items-center justify-between group cursor-pointer" onClick={() => handleReadClick(driveLinks[subject.id], `Master ${subject.title}`)}>
                        <div className="flex items-center gap-8">
                          <div className="h-16 w-16 rounded-3xl bg-primary/10 flex items-center justify-center shrink-0 border border-primary/20">
                            <ShieldCheck className="h-8 w-8 text-primary" />
                          </div>
                          <div>
                            <p className="font-black text-xl uppercase leading-tight mb-2">Official Master Repository</p>
                            <span className="text-[11px] font-black text-primary uppercase tracking-widest bg-primary/10 px-4 py-1 rounded-full">Pro Access</span>
                          </div>
                        </div>
                        <div className="flex gap-4">
                          <Button size="lg" className="rounded-2xl font-black text-[11px] h-14 px-10 tracking-widest shadow-lg shadow-primary/20">OPEN DRIVE</Button>
                        </div>
                      </div>
                    )}
                    {subjectDbMaterials.map((m) => (
                      <div key={m.id} className="p-10 hover:bg-secondary/30 transition-all flex items-center justify-between cursor-pointer group" onClick={() => handleReadClick(m.content, m.title)}>
                        <div className="flex items-center gap-8">
                          <div className="h-16 w-16 rounded-3xl bg-secondary flex items-center justify-center shrink-0 group-hover:bg-background transition-all">
                            <FileText className="h-8 w-8 text-muted-foreground" />
                          </div>
                          <div>
                            <p className="font-black text-xl uppercase leading-tight mb-1 truncate max-w-[200px] md:max-w-xs">{m.title}</p>
                            <span className="text-[11px] font-black text-muted-foreground uppercase tracking-widest">Library Resource</span>
                          </div>
                        </div>
                        <div className="flex gap-3">
                          <Button variant="outline" className="h-14 w-14 rounded-2xl border-2 hover:bg-foreground hover:text-background"><Eye className="h-6 w-6" /></Button>
                        </div>
                      </div>
                    ))}
                    {!hasMasterLink && subjectDbMaterials.length === 0 && (
                      <div className="p-20 text-center">
                        <p className="text-muted-foreground font-black uppercase text-[10px] tracking-[0.2em]">New resources coming soon...</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </main>
    </div>
  )
}
