/**
 * @fileOverview Static question bank for reliable practice sets.
 * Contains 50 rounds of questions for different subjects.
 */

export interface Question {
  question: string;
  options: string[];
  correctAnswer: string;
}

export interface PracticeSet {
  id: string;
  title: string;
  subject: string;
  questions: Question[];
}

const reasoningPool: Question[] = [
  { question: "P is the brother of Q. R is the mother of Q. S is the father of R. How is P related to S?", options: ["Grandson", "Son", "Brother", "Father"], correctAnswer: "Grandson" },
  { question: "If 'A + B' means A is the father of B, and 'A - B' means A is the mother of B, what does 'P + R - Q' mean?", options: ["P is the grandfather of Q", "P is the uncle of Q", "P is the brother of Q", "P is the son of Q"], correctAnswer: "P is the grandfather of Q" },
  { question: "Pointing to a photograph, a man said, 'I have no brother or sister but that man's father is my father's son.' Whose photograph was it?", options: ["His son's", "His own", "His father's", "His nephew's"], correctAnswer: "His son's" },
  { question: "In a family of 3 generations, there are 2 couples. If A is the daughter of B and B is the son of C, how is A related to C?", options: ["Grand-daughter", "Daughter", "Mother", "Niece"], correctAnswer: "Grand-daughter" },
  { question: "If 'TANGERINE' is coded as 'REGINATNE', then 'EDUCATION' will be coded as?", options: ["NOITACUDE", "NOITACUED", "NOIATCUE", "NOITACEUD"], correctAnswer: "NOITACUDE" },
  { question: "Find the missing number in the series: 2, 6, 12, 20, 30, ?", options: ["42", "40", "38", "44"], correctAnswer: "42" },
  { question: "A is 40m South-West of B. C is 40m South-East of B. Then C is in which direction of A?", options: ["East", "West", "North", "South"], correctAnswer: "East" },
  { question: "If South-East becomes North, North-East becomes West and so on. What will West become?", options: ["South-East", "North-East", "South-West", "North-West"], correctAnswer: "South-East" },
  { question: "Which word does NOT belong with the others?", options: ["Tyre", "Steering Wheel", "Engine", "Car"], correctAnswer: "Car" },
  { question: "Look at this series: 7, 10, 8, 11, 9, 12, ... What number should come next?", options: ["10", "7", "13", "11"], correctAnswer: "10" }
];

const constitutionPool: Question[] = [
  { question: "Who is the Constitutional Head of India?", options: ["President", "Prime Minister", "Chief Justice", "Governor"], correctAnswer: "President" },
  { question: "The concept of 'Fundamental Rights' was borrowed from which country?", options: ["USA", "UK", "USSR", "Ireland"], correctAnswer: "USA" },
  { question: "Which Article of the Constitution is known as the 'Soul of the Constitution'?", options: ["Article 32", "Article 21", "Article 14", "Article 19"], correctAnswer: "Article 32" },
  { question: "How many schedules are there in the Indian Constitution originally?", options: ["8", "10", "12", "7"], correctAnswer: "8" },
  { question: "The Rajya Sabha is presided over by?", options: ["Vice President", "Speaker", "Prime Minister", "President"], correctAnswer: "Vice President" },
  { question: "What is the minimum age to become the Prime Minister of India?", options: ["25 years", "30 years", "35 years", "21 years"], correctAnswer: "25 years" },
  { question: "Which Amendment added the word 'Secular' to the Preamble?", options: ["42nd Amendment", "44th Amendment", "1st Amendment", "73rd Amendment"], correctAnswer: "42nd Amendment" },
  { question: "Who appoints the Chief Justice of India?", options: ["President", "Prime Minister", "Law Minister", "Parliament"], correctAnswer: "President" },
  { question: "The Directive Principles of State Policy are mentioned in which Part?", options: ["Part IV", "Part III", "Part II", "Part V"], correctAnswer: "Part IV" },
  { question: "Panchayati Raj was first introduced in which state?", options: ["Rajasthan", "Gujarat", "Maharashtra", "Tamil Nadu"], correctAnswer: "Rajasthan" }
];

const shuffle = (array: any[]) => [...array].sort(() => Math.random() - 0.5);

export const getAllPracticeSets = (): PracticeSet[] => {
  const sets: PracticeSet[] = [];
  for (let i = 1; i <= 50; i++) {
    const isEven = i % 2 === 0;
    const baseQuestions = isEven ? constitutionPool : reasoningPool;
    const subject = isEven ? "Constitution" : "Reasoning";
    const setQuestions = shuffle([...baseQuestions, ...baseQuestions]).slice(0, 15);
    sets.push({
      id: `set-${i}`,
      title: `Practice Round ${i}`,
      subject: subject,
      questions: setQuestions
    });
  }
  return sets;
};

export const getPracticeSetById = (id: string): PracticeSet | undefined => {
  return getAllPracticeSets().find(s => s.id === id);
};
